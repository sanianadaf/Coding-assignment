#include<iostream>
using namespace std;

int main(){
    int n, num=1;
    cout<<"Enter the number: ";
    cin>>n;
    
    //checks if the input was successful. if it fails it means that a character was entered instead of a number
    if(cin.fail()){
        cout<<"Invalid input. Please enter a valid number."<<endl;
        return 0;
    }
    else if(n <0){
        cout<<"cannot find factorial of a negative number"<<endl;
    }
    else for(int i=1; i<=n; i++){
        num = num*i;
    }
    cout<<"Factorial of "<< n<<" is: "<<num;
}